<!-- <?php include "model/stack.php"; $stack = new Stacks();?> -->
<!DOCTYPE html>
<html>
<head>

	<?php include "model/Bootstrap.php"; ?>

    <script src="../Bootstrap/vendor/jquery/jquery.min.js"></script>
    <script src="../Bootstrap/vendor/bootstrap/js/bootstrap.min.js"></script>
    <style type="text/css">
      
    </style>
    <script type="text/javascript">
      $(document).ready(function(){
        $("#loading-page").load("index.php?homepage=Portfolio/Hire", function(responseTxt, statusTxt, xhr){
        });
        $('#unhire').click(function(){
          $("#loading-page").load("index.php?homepage=Portfolio/Unhire", function(responseTxt, statusTxt, xhr){
        });
          $('#hired').click(function(){
          $("#loading-page").load("index.php?homepage=Portfolio/Hire", function(responseTxt, statusTxt, xhr){
        });
        });
      });
    </script>
    <style type="text/css">
      #notif:hover{background-color: #d0d0d0;}
      #notif a {color: #000000; text-decoration: none;}
      #notif{padding:5px;}
    </style>
</head>
<body id="page-top" style="background-image: url('../Bootstrap/img/header-bg.jpg');">
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Tan Agency</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Portfolio">Portfolio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Post">Post</a>
            </li>
            <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#">
              <img class="img-circle" src="<?=$img;?>" width="20">
              <?=$name;?>
            </a>
            </li>
            <li class="nav-item">
            <div class="dropdown">
            
            <?php $count = count($this->model->getTransactionsNotifCount()) + count($unApprove);?>
              <a class="nav-link js-scroll-trigger dropdown-toggle" data-toggle="dropdown" href="#"><span class="fa fa-globe"><?=$count;?></span>
              </a>
              <ul class="dropdown-menu" style="padding: 10px; width: 300px; margin-left: -20px;  overflow: auto; height: 500px;">
              <?php
                if(count($trans_notif) > 0){
                  foreach ($trans_notif as $notif) {
                    if($notif['notif']==0){
                      echo '<li style="background-color:#e0e0e0;" id="notif"><a href="index.php?homepage=Transaction&transaction_no='.$notif['tr_id'].'&admin_id='.$admin_id.'&notif=1">
                    <p class="pull-right"><img src="'.$notif['app_img'].'" style="width:30px; height:30px;"><br>
                      <i class="small text-muted">'.$notif['app_lname'].'</i></p>
                      <img src="'.$notif['user_img'].'" style="width:40px; height:40px;"> 
                      '.$notif['user_name'].' <br> <i class="text-muted" style="margin-left:40px;">Wants to connect with</i> 
                      
                      </a></li><hr>';
                    
                    }
                    else{
                      echo '<li id="notif"><a href="index.php?homepage=Transaction&transaction_no='.$notif['tr_id'].'&admin_id='.$admin_id.'&notif=1">
                    <p class="pull-right"><img src="'.$notif['app_img'].'" style="width:30px; height:30px;"><br>
                      <i class="small text-muted">'.$notif['app_lname'].'</i></p>
                      <img src="'.$notif['user_img'].'" style="width:40px; height:40px;"> 
                      '.$notif['user_name'].' <br> <i class="text-muted" style="margin-left:40px;">Wants to connect with</i> 
                      
                      </a></li><hr>';
                      
                    }
                    
                  } 
                }
                if(count($unApprove) > 0){
                  foreach ($unApprove as $up) {
                    
                      echo '<li id="notif">
                      <a href="index.php?homepage=Portfolio/Applicant&app_id='.$up['app_id'].'"><img src="'.$up['app_img'].'" style="width:40px; height:40px;"> 
                      '.$up['app_lname'].', '.$up['app_fname'].' <br> <i class="text-muted" style="margin-left:40px;">Wants to Apply</i> 
                      
                      </a></li><hr>';
                  }
                }
              ?>
              </ul>
            </div>
            </li>

            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?logout=1">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
