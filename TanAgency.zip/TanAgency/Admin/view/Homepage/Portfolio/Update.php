<?php
        $app_id = $_GET['app_id'];
        $lname = $_GET['app_lname'];
        $fname = $_GET['app_fname'];
        $age = $_GET['app_age'];
        $gender = $_GET['app_gender'];
        $address = $_GET['app_address'];
        $contact = $_GET['app_contact'];
        $status = $_GET['status'];
        $img = $_GET['app_img'];
?>
            <section>
              <div class="row" >
              <div class="col-md-3"></div>
                      <div class="col-md-8 form quick-post">
                                      <!-- Edit profile form (not working)-->
                                      <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                          <!-- Title -->
                                          <label class="control-label col-lg-2" for="title" style="color:#fefefe;"><h1>UPDATE</h1></label>
                                          <input type="hidden" name="app_id" value="<?=$app_id?>">
                                          <div class="col-lg-10 col-lg-6 col-lg-4">
                                              <div class="form-group">
                                                <img src="<?=$img;?>" width="200">
                                              </div>
                                            </div>
                                            <div class="form-group">
                                          <label class="control-label col-lg-2" for="title" style="color:#fefefe;"><h6>Picture</h6></label>
                                            <div class="col-lg-10">
                                              <input type="file" class="btn btn-success" name="fileToUpload" required="">
                                            </div>
                                          </div>
                                            <div class="col-lg-10 col-lg-6 col-lg-4">
                                              <div class="form-group">
                                                <input type="text" name="fname" value="<?=$fname?>" class="form-control" placeholder="Firstname" required="">
                                              </div>
                                            </div>
                                             
                                            <div class="col-lg-10 col-lg-6 col-lg-4">
                                              <div class="form-group">
                                                <input type="text" name="lname" value="<?=$lname?>" class="form-control"  placeholder="Lastname" required="">
                                              </div>
                                            </div> 
                                          <div class="form-group">
                                            <div class="col-lg-10">
                                              <input type="text" class="form-control" name="age" value="<?=$age?>" placeholder="Age" required="">
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <div class="col-lg-10">                               
                                                <select class="form-control" name="gender" required="">
                                                  <option value="">- Gender -</option>
                                                  <option value="M" <?php if($gender == "M") echo "Selected";?> >Male</option>
                                                  <option value="F" <?php if($gender == "F") echo "Selected";?>>Female</option>
                                                </select>  
                                            </div>
                                          </div>         
                                          <!-- Tags -->
                                          
                                          <div class="form-group">
                                            <div class="col-lg-10">
                                              <input type="text" class="form-control" name="address" value="<?=$address?>" placeholder="Address" required="">
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <div class="col-lg-10">
                                              <input type="text" class="form-control" name="contact" value="<?=$contact?>" placeholder="Contact" required="">
                                            </div>
                                          </div>
                                          
                                          <div class="form-group">
                                            <div class="col-lg-10">                               
                                                <select class="form-control" name="status" required="">
                                                  <option value="">- Status -</option>
                                                  <option value="0" <?php if($status == "0") echo "Selected";?> >Unhire</option>
                                                  <option value="1" <?php if($status == "1") echo "Selected";?> >Hire</option>
                                                </select>  
                                            </div>
                                          </div>
                                          
                                          <div class="form-group">
                                          <label class="control-label col-lg-2" for="title" style="color:#fefefe;"><h6>Resume</h6></label>
                                            <div class="col-lg-10">
                                              <input type="file" class="btn btn-info" name="uploaded"  required="">
                                            </div>
                                          </div>
                                          <!-- Buttons -->
                                          <div class="form-group">
                                             <!-- Buttons -->
                       <div class="col-lg-offset-2 col-lg-9">
                        <button type="submit" name="update_applicant" class="btn btn-primary">UPDATE</button>
                        <a href="index.php?homepage=Portfolio" class="btn btn-danger">Cancel</a>
                        
                       </div>
                                          </div>
                                      </form>
                                    </div>
            </div>
          </section>