<section class="" id="portfolio">
      <div class="container">
        <table class="table table-stripped" style="background-color: #fefefe;">
        <th>PHOTO</th><th>NAME</th><th>AGE</th><th>GENDER</th><th>ADDRESS</th><th>PHONE</th><th>RESUME</th><th>DATE REGISTER</th><th>REMARK</th>
          <?php
            foreach ($applicant as $app) {
              $status=null;
              if($app['app_status'] == 0) $status = "<a href='index.php?app_status=".$app['app_status']."&app_id=".$app['app_id']."' class='btn btn-info'>UNHIRE</a>";
              else $status = "<a href='index.php?app_status=".$app['app_status']."&app_id=".$app['app_id']."' class='btn btn-success'>HIRE</a>";
              echo "<tr>";
                echo "<td><img src='".$app['app_img']."' width='50'></td>";
                echo "<td>".$app['app_lname'].", ".$app['app_fname']."</td>";
                echo "<td>".$app['app_age']."</td>";
                echo "<td>".$app['app_gender']."</td>";
                echo "<td>".$app['app_address']."</td>";
                echo "<td>".$app['app_contact']."</td>";
                echo "<td><a href='index.php?file=".$app['app_resume']."'>Resume</a></td>";
                echo "<td>".$app['date_register']."</td>";
                echo "<td>".$status."</td>";
              echo "</tr>";
            }
          ?>
        </table>
      </div>
    </section>
