<?php
	include_once("controller/Controller.php");		
		
	$controller	= new Controller();		
	$controller->invoke();
?>