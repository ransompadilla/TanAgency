<?php
	/**
	* 
	*/
	class Stacks
	{
		private $ctr;
		private $arr;
		function __construct()
		{
			$this->ctr=0;
			$this->arr = array();
		}
		public function push($item){
			$this->arr[$this->ctr++] = $item;
			//$this->ctr++;
		}
		public function isFind($item){
			for($i=0;$i<$this->ctr;$i++){
				if($this->arr[$i]==$item){
					return $item;
					break;
				}
			}
		}
		public function display(){
			for($i=0;$i<$this->ctr;$i++){
				return $this->arr[$i];
			}
		}
		public function itemsArray(){
			return $this->arr;
		}
		public function count(){return $this->ctr;}
	}
?>