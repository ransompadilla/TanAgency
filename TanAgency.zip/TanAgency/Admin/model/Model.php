<?php
	include_once("Crud.php");
	class Model{
		private $crud;
		public function __construct(){
			$this->crud = new Crud();
		}
        //REGISTER
		public function RegisterAdmin($data){
            $query = "INSERT INTO admin(admin_name, admin_address, admin_email, admin_password, admin_img) VALUES(?,?,?,?,?)";
            $this->crud->Insert($query,$data);

        }
        public function RegisterApplicant($data){
            $query = "INSERT INTO applicant_info(app_lname, app_fname, app_age, app_gender, app_address, app_contact, app_img, app_resume, app_status,active) VALUES(?,?,?,?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        //SEND MESSAGE
        public function SendMessages($data){
         $query = "INSERT INTO message(tr_id, sender, messages) VALUES(?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function ChangeEmail($table,$data){
            $query = "UPDATE $table set cust_email=? where cust_id=?";
            $this->crud->Update($query,$data);

        }
        public function ChangePassword($table,$data){
            $query = "UPDATE $table set cust_password=? where cust_id=?";
            $this->crud->Update($query,$data);

        }
        //VALIDATE LOGIN
        public function ValidateAdminLogin($data){
            $query = "SELECT * FROM admin where admin_email=? and admin_password=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //LOGOUT
        public function Admin_Logout(){
            if(isset($_COOKIE['admin_id'])){
                setcookie("admin_id",$_COOKIE['admin_id'], time() - 86400 ,"/");
                header("Location: index.php");
            }
        }
        //USER SIDE

        public function getUserNameByID($data){
            $name=null;
            $query = "SELECT user_name FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['user_name'];
            }
            return $name;
        }
        public function getUserImgByID($data){
            $img=null;
            $query = "SELECT user_img FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $img = $row['user_img'];
            }
            else $img=null;
            return $img;
        }
        //
        public function getAdminNameByID($data){
            $name=null;
            $query = "SELECT admin_name FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['admin_name'];
            }
            return $name;
        }
        public function getAdminImgByID($data){
            $img=null;
            $query = "SELECT admin_img FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $img = $row['admin_img'];
            }
            else $img=null;
            return $img;
        }
        public function getApplicant(){
          $query = "SELECT * FROM applicant_info WHERE active=1 and approve=1;";
          $row = $this->crud->SelectAll($query);
          return $row;  
        }
        public function getApplicantUpApprove(){
          $query = "SELECT * FROM applicant_info WHERE active=1 and approve=0;";
          $row = $this->crud->SelectAll($query);
          return $row;  
        }
        public function getPortfolio($data){
            $query = "SELECT * FROM applicant_info WHERE app_id=? and active=1";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //TRANSACTIONS
        public function getTransactionsNotif(){
            $query = "SELECT a.*, t.*, u.* FROM  transaction t, applicant_info a, user u WHERE t.app_id=a.app_id and t.user_id=u.user_id and a.active=1 and a.approve=1 ORDER BY date_trans DESC";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getTransactionsNotifCount(){
            $query = "SELECT notif FROM  transaction WHERE notif=0;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getTransactions($data){
            $query = "SELECT a.*, t.* FROM applicant_info a JOIN transaction t ON t.app_id=a.app_id WHERE t.tr_id=? and a.active=1 and a.approve=1";
            $row = $this->crud->Select($query,$data);
            return $row;
        }

        public function getMessages($data){
            $query = "SELECT * FROM message WHERE tr_id=$data ORDER BY date DESC;";
            $row = $this->crud->SelectAll($query);
            return $row;           
        }
        //UPDATE TRANSACTION
        public function ApproveApplicant($data){
            $query = "UPDATE applicant_info SET approve=? WHERE app_id=?";
            $this->crud->Update($query,$data);
        }
        public function UpdateNotifTransaction($data){
            $query = "UPDATE transaction SET admin_id=?, notif=? WHERE tr_id=?;";
            $this->crud->Update($query,$data);
        }
        //UPDATE APPLicANT
        public function UpdateAppStatus($data){
            $query = "UPDATE applicant_info SET app_status=? WHERE app_id=?";
            $this->crud->Update($query,$data);
        }
        public function UpdateApplicant($data){
            $query = "UPDATE applicant_info SET app_lname=?,app_fname=?,app_age=?, app_gender=?, app_address=?, app_contact=?, app_img=?, app_resume=?, app_status=? WHERE app_id=?";
            $this->crud->Update($query,$data);
        }
        public function DeleteApplicant($data){
            $query = "UPDATE applicant_info SET active=0 WHERE app_id=?";
            $this->crud->Update($query,$data);
        }
	}
?>