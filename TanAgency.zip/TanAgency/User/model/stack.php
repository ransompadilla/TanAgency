<?php
	/**
	* 
	*/
	class Stack
	{
		private $ctr;
		private $arr;
		function __construct()
		{
			$this->ctr=0;
			$this->arr = array();
		}
		public function push($item){
			$this->arr[$this->ctr++] = $item;
			//$this->ctr++;
		}
		public function isFind($item){
			for($i=0;$i<$this->ctr;$i++){
				if($this->arr[$i]==$item){
					return $item;
					break;
				}
			}
		}
		public function display(){
			var_dump($this->ctr);
			for($i=0;$i<$this->ctr;$i++){
				echo $this->arr[$i];
			}
		}
		public function count(){return $this->ctr;}
	}
?>