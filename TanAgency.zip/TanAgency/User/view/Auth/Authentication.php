<?php include "view/Auth/AuthHeader.php";?>
           
        <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <div class="col-md-12">
                  <label><h1>Authentication</h1> </label>
                  <form class="login-form" method="POST">   
                  <div class='alert alert-danger alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>Invalid Username or Password !</div>
                  <div class="form-group">
                    <input class="form-control" name="email" type="email" placeholder="Your Email *" required data-validation-required-message="Please enter your email address.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" name="password" type="password" placeholder="Your Password *" required="">
                    <p class="help-block text-danger"></p>
                  </div>
                  <button class="btn btn-info" name="login_user" style="width: 100%">
                    Login</button>
                </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
      
      <?php include "view/Auth/AuthFooter.php";?>