<!DOCTYPE html>
<html>
<head>
	<?php include "model/Bootstrap.php"; ?>
  <script src="../Bootstrap/vendor/jquery/jquery.min.js"></script>
    <script src="../Bootstrap/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script type="text/javascript">
  $(document).ready(function(){
    //alert("asdf");
    $('.appendhere').hide();
    $('.appendInput').change(function(){
      var value = $(this).val();
      if(value==2){
      $('.appendhere').show();
      }
      else if(value==1){
      $('.appendhere').hide();
      }
    });
   });
  //   function appendInput(value){

  //   $('#appendhere').show();

  //     // if(value == 2){

  //     // alert(value);
  //     // var d=document.createElement('input');
  //     //   d.setAttribute('type', 'text');
  //     //   d.setAttribute('class', 'form-control');
  //     //   d.setAttribute('name', 'status');

  //     //   document.getElementById('appendhere').appendChild(d);
  //     // }
  //   }
  </script>
  <style type="text/css">
      #notif:hover{background-color: #d0d0d0;}
      #notif a {color: #000000; text-decoration: none;}
      #notif{padding:5px;}
    </style>
</head>
<body id="page-top" style="background-image: url('../Bootstrap/img/header-bg.jpg');">
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Tan Agency</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Portfolio">Portfolio</a>
            </li>

            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Post">Post</a>
            </li>
            <li class="nav-item">
            <div class="dropdown">
            
            <?php $count = count($this->model->getMessageNotif($user_id));?>
              <a class="nav-link js-scroll-trigger dropdown-toggle" data-toggle="dropdown" href="#"><span class="fa fa-globe"><i class="badge"><?=$count;?></i></span>
              </a>
              <ul class="dropdown-menu" style="padding: 10px; width: 300px; margin-left: -20px;  overflow: auto; height: 500px;">
              <?php
                foreach ($transaction as $tr) {
                  echo '<li style="background-color:#e0e0e0;" id="notif"><a href="index.php?homepage=Transaction&transaction_no='.$tr['tr_id'].'">
                    <p class="pull-right"><img src="'.$tr['app_img'].'" style="width:30px; height:30px;"><br>
                      <i class="small text-muted">'.$tr['app_lname'].'</i></p>
                      <img src="'.$tr['admin_img'].'" style="width:40px; height:40px;"> 
                      '.$tr['admin_name'].' <br> <i class="small text-muted" style="margin-left:40px;">have message on your post</i> 
                      
                      </a></li><hr>';
                }
              ?>
              </ul>
            </div>
            </li>
            <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#">
              <img class="img-circle" src="<?=$img;?>" width="20">
              <?=$name;?>
            </a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?logout=1">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

