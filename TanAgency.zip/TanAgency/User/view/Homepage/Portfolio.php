<!-- Portfolio Grid -->
    <section class="bg-light" id="" style="background-image: url('../Bootstrap/img/header-bg.jpg');">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading" style="color: #fefefe;">My Portfolio</h2>
            <div class="btn btn-info">
            <?php
              foreach ($portfolio as $p) {
                echo "<a href='index.php?homepage=Portfolio/Update&app_id=".$p['app_id']."&app_img=".$p['app_img']."&app_lname=".$p['app_lname']."&app_fname=".$p['app_fname']."&app_age=".$p['app_age']."&app_gender=".$p['app_gender']."&app_address=".$p['app_address']."&app_contact=".$p['app_contact']."&app_resume=".$p['app_resume']."&status=".$p['app_status']."' class='fa fa-edit'></a> <a href='index.php?id=".$p['app_id']."' class='fa fa-trash'></a>";
                echo "<br><br><img src='".$p['app_img']."' width='400'><br><br>";
                echo "<div class='pull-right'>".$p['app_address']."</div>";
                echo "<div class='pull-left'>NAME: ".$p['app_lname'].", ".$p['app_fname']."</div>";
                echo "<br><div class='pull-right'> #".$p['app_contact']."</div>";

                echo "<div class='pull-left'>AGE: ".$p['app_age']." - ".$p['app_gender']."</div>";
                echo "<br><a class='btn btn-danger' style='width:100%;' href='index.php?file=".$p['app_resume']."'>Download Resume</a>";
              }
            ?>
            </div>
          </div>
        </div>
                  
        </div>
      </div>
    </section>
