<div class="container">
  
  <!-- Left-aligned media object -->
  <?php
  $trans=null;
     if(isset($_GET['transaction_no'])){

        $trans = $this->model->getTransactionWith(array($_GET['transaction_no']));
     }
    if(count($trans) > 0){
        # code...
      
  $message = $this->model->getMessages($trans['tr_id']);                   
      echo '
      <div style="margin-top: 10%; color: #aeaeae;">

  <div class="media" >
    <div class="media-left">
      <img src="'.$trans['app_img'].'" class="media-object" style="width:100px; height: 100px;">
    </div>
    <div class="media-body" style="margin-left: 10px;">
      <h5 class="media-heading" > '.$trans['app_lname'].", ".$trans['app_fname'].'</h5>
      <p> '.$trans['message'].'<br>';
        $d = strtotime($trans['date_trans']);
        $date = Date('F j, Y h:i A',$d);
        echo "<i class='small text-muted'>$date";
      echo '</p>
    </div>
  </div>
  <hr>
  <div style="margin-left: 10%; color: #aeaeae;">';
  $imgs='';$names='';
  foreach ($message as $m) {

        if($m['sender'] == $user_id){
          $imgs = $this->model->getUserImgByID(array($m['sender']));
          $names = $this->model->getUserNameByID(array($m['sender']));
        }
        else{
          $imgs = $this->model->getAdminImgByID(array($m['sender']));
          $names = $this->model->getAdminNameByID(array($m['sender']));
        }
         
     
      echo '<div class="media" >
        <div class="media-left">
          <img src="'.$imgs.'" class="media-object" style="width:60px; height: 60px;">
        </div>
        <div class="media-body" style="margin-left: 10px;">
          <h5 class="media-heading" > '.$names.'</h5>
          <p> '.$m['messages'].'<br>';
            $d = strtotime($m['date']);
            $date = Date('F j, Y h:i A',$d);
            echo "<i class='small text-muted'>$date</i>";
          echo '</p>
        </div>
      </div><hr>';
  }
  echo '</div>
  <form method="POST">
  <p>
  <input type="hidden" name="tr_id" value="'.$tr['tr_id'].'">
  <input type="hidden" name="sender" value="'.$user_id.'">
  <img src="'.$img.'" style="width: 40px;height:40px;margin-top: -35px;">
  <textarea class="form" name="message" style="width: 70%;height:40px;" placeholder="Write messages..."></textarea>
  <button type="submit" name="send_message" class="btn btn-default" style="margin-top: -33px;">Send</button>
  </p>
  </form>

  </div>
      ';
    
    }
    else{
      echo '<div style="margin-top: 10%;" class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> NO transS..</div>';
    }
    
  ?>
  
</div>
