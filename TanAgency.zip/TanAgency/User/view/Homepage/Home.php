<!-- Portfolio Grid -->
    <section class="bg-light" id="" style="background-image: url('../Bootstrap/img/header-bg.jpg');">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading" style="color: #fefefe;">Hire me</h2>
          </div>
        </div>
        <div class="row">
        <?php
          foreach ($available_guard as $av) {
            echo '
              <div class="col-md-4 col-sm-6 portfolio-item" >
            <a class="portfolio-link" data-toggle="modal" href="#viewapp'.$av['app_id'].'">
              <div class="portfolio-hover" >
                <div class="portfolio-hover-content">
                  
                </div>
              </div>
              <img class="img-fluid" src="'.$av['app_img'].'" alt="'.$av['app_lname'].'" style="height:50%; width:100%;">
            </a>
            <div class="portfolio-caption" style="background-color: white; padding:8px; text-align:center;">
              <h4>'.$av['app_lname'].', '.$av['app_fname'].' - '.$av['app_age'].'</h4>
              <h6></h6>
              <h6>'.$av['app_address'].'</h6>';
                $d = strtotime($av['date_register']);
                $date_register = Date('F j, Y @ h:i A', $d);
              echo '<p class="text-muted">'.$date_register.'</p>
            </div>
          </div>
            ';
          }

          //Modals
          for ($i=1; $i<=$maximum ; $i++) { 
            $app = $this->model->getApplicantInfo(array($i));
            echo '
                   <div class="portfolio-modal modal fade" id="viewapp'.$i.'" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                  <div class="lr">
                    <div class="rl"></div>
                  </div>
                </div>
                <div class="container">
                  <div class="row">
                    <div class="col-lg-8 mx-auto">
                      <div class="modal-body">
                        <!-- Project Details Go Here -->
                        <form method="POST">
                        <h2>Hire me</h2>
                        <p class="item-intro text-muted"></p>
                        <img class="img-fluid d-block mx-auto" src="'.$app['app_img'].'" alt="'.$app['app_lname'].'" style="height:50%; width:80%;">
                        <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                        <h6 class="list-inline">
                          <p>Name: '.$app['app_lname'].', '.$app['app_fname'].'<br>
                          Age: '.$app['app_age'].'<br>
                          Gender: '.$app['app_gender'].'<br>
                          Address: '.$app['app_address'].'</p>';

                          $d = strtotime($av['date_register']);
                          $date_register = Date('F j, Y @ h:i A', $d);

                          echo '<p class="text-muted">'.$date_register.'</p>
                          <p class="pull-left"> Leave message here: </p>
                          <textarea type="text" class="form-control" name="message" placeholder="Set schedule for interview" style="height: 100px;"/></textarea><br>
                          
                        </h6>
                        
                        <input type="hidden" name="app_id" value="'.$app['app_id'].'">
                        <input type="hidden" name="user_id" value="'.$user_id.'">
                        <a href="index.php?file='.$app['app_resume'].'" class="btn btn-primary"><span class="fa fa-download"> Download Resume</span></a>
                        <button type="submit" name="hire" class="btn btn-success"><span class="fa fa-send"> Send</span></button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
       
            ';
          }
        ?>

        </div>
      </div>
    </section>
