            <section>
              <div class="row" >
              <div class="col-md-3"></div>
                      <div class="col-md-8 form quick-post">
                                      <!-- Edit profile form (not working)-->
                                      <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                          <!-- Title -->
                                          <label class="control-label col-lg-2" for="title" style="color:#fefefe;"><h1>POST</h1></label>
                                          <input type="hidden" name="user_id" value="<?=$user_id;?>">
                                            <div class="col-lg-10 col-lg-6 col-lg-4">
                                              <div class="form-group">
                                                <input type="text" name="fname" class="form-control" placeholder="Firstname" required="">
                                              </div>
                                            </div>
                                             
                                            <div class="col-lg-10 col-lg-6 col-lg-4">
                                              <div class="form-group">
                                                <input type="text" name="lname" class="form-control"  placeholder="Lastname" required="">
                                              </div>
                                            </div> 
                                          <div class="form-group">
                                            <div class="col-lg-10">
                                              <input type="text" class="form-control" name="age" placeholder="Age" required="">
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <div class="col-lg-10">                               
                                                <select class="form-control" name="gender" required="">
                                                  <option value="">- Gender -</option>
                                                  <option value="M">Male</option>
                                                  <option value="F">Female</option>
                                                </select>  
                                            </div>
                                          </div>              
                                          <!-- Tags -->
                                          
                                          <div class="form-group">
                                            <div class="col-lg-10">
                                              <input type="text" class="form-control" name="address" placeholder="Address" required="">
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <div class="col-lg-10">
                                              <input type="text" class="form-control" name="contact" placeholder="Contact" required="">
                                            </div>
                                          </div>
                                          
                                          <div class="form-group">
                                          <label class="control-label col-lg-2" for="title" style="color:#fefefe;"><h6>Picture</h6></label>
                                            <div class="col-lg-10">
                                              <input type="file" class="btn btn-success" name="fileToUpload" required="">
                                            </div>
                                          </div>
                                          <div class="form-group">
                                          <label class="control-label col-lg-2" for="title" style="color:#fefefe;"><h6>Resume</h6></label>
                                            <div class="col-lg-10">
                                              <input type="file" class="btn btn-info" name="uploaded"  required="">
                                            </div>
                                          </div>
                                          <!-- Buttons -->
                                          <div class="form-group">
                                             <!-- Buttons -->
											 <div class="col-lg-offset-2 col-lg-9">
												<button type="submit" name="register_applicant" class="btn btn-primary">POST</button>
												
											 </div>
                                          </div>
                                      </form>
                                    </div>
            </div>
          </section>